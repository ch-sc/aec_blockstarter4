import React, {Component} from 'react';
import main from './CreateProject';
import DeleteRefund from './DeleteRefund'

// this is the main page for editing, which lets user to navigate to CreateProject 
// DeleteRefund pages

class Edit extends Component{
	render(){
		return(
			<div className ="">
				<a className="" onClick="{CreateProject}" >Create new project </a>
				<a className="" onClick="{DeleteRefund}" >Cancel project</a>
			</div>
			)
	}
}

export default Edit;