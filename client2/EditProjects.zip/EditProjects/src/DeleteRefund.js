import React, {Component} from 'react';
// solidity code must be imoprt her and  the kill function must be called on submit of form

class Delete extends Component{
	render(){
		return(
			<div className ="">
				<form onSubmit={kill}>
      <div>
        <label>Title</label>
        <div>
          <Field
            required="required"
            name="address"
            component="input"
            type="text"
            placeholder="Project address"
          />
        </div>
      </div>
     
      <div>
        <button type="submit" disabled={pristine || submitting}>Delete</button>
       
      </div>
    </form>
			</div>
			)
	}
}

export default Delete;