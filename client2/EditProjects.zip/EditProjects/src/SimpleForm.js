import React from 'react';
import { Field, reduxForm } from 'redux-form';

//returns the form for new project creation
const SimpleForm = props => {
  const { handleSubmit, pristine, reset, submitting } = props;
  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Title</label>
        <div>
          <Field
            required="required"
            name="title"
            component="input"
            type="text"
            placeholder="Project title"
          />
        </div>
      </div>
      <div>
        <label>Description</label>
        <div>
          <Field
            name="description"
            component="textarea"
            type="text"
            placeholder="Description"
          />
        </div>
      </div>
      <div>
        <label>Projecr start date</label>
        <div>
          <Field
              required="required"
              name="start-date"
              component="input"
              type="date"
              placeholder="dd-mm-yy"
            
            />
        </div>
      </div>
       
      <div>
        <label>Projecr end  date</label>
        <div>
          <Field
              required="required"
              name="end-date"
              component="input"
              type="date"
              placeholder="dd-mm-yy"
            
            />
        </div>
      </div>
      <div>
        <label>Funding goal</label>
        <div>
          <Field
            required="required"
            name="goal"
            component="input"
            type="number"
            placeholder="Funding goal"
          />
        </div>
      </div>
      <div>
        <label>Funding start date</label>
        <div>
          <Field
              required="required"
              name="fund-start-date"
              component="input"
              type="date"
              placeholder="dd-mm-yy"
            
            />
        </div>
      </div>
      
      <div>
        <label>Funding end  date</label>
        <div>
          <Field
              required="required"
              name="fund-end-date"
              component="input"
              type="date"
              placeholder="dd-mm-yy"
              
            />
        </div>
      </div>
      
     
      <div>
        <button type="submit" disabled={pristine || submitting}>Submit</button>
       
      </div>
    </form>
  );
};

export default reduxForm({
  form: 'simple', // a unique identifier for this form
})(SimpleForm);
